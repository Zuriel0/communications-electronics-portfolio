Intermediate series. Source/build changed while this series ran; excluded from final acceptance and metrics. Retained for audit history.
